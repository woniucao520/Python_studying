#encoding:utf-8  
import sys
import re
import os
import time
from selenium import webdriver
from selenium.webdriver.support.ui import WebDriverWait

reload(sys)
sys.setdefaultencoding('utf-8')


def readText(url, browser):
	try:
		browser.get(url)
		time.sleep(5)
		text = browser.page_source
	except Exception,e:
		print 'timeout, can not open url:%s, err:%s, continue next ' % (url, e)
		return ''
	
	return text 
	
def logIn(url, browser):
	try:
		browser.get(url)
		WebDriverWait(browser, 60).until(lambda brow: brow.find_element_by_xpath("//input[@name='login[username]']"))
		element = browser.find_element_by_xpath("//input[@name='login[username]']")
		element.clear()
		element.send_keys('15861247225')
		
		element = browser.find_element_by_xpath("//input[@name='login[password]']")
		element.clear()
		element.send_keys('123456')
		
		element = browser.find_element_by_xpath("//button[@name ='send']")
		element.submit()
		time.sleep(5)
	except Exception,e:
		print 'timeout, can not open url:%s, err:%s, continue next ' % (url, e)
		return


def main():
	browser = webdriver.PhantomJS()
	browser.set_page_load_timeout(60)
	
	logInUrl = 'https://www.24th.com/customer/account/login/'
	logIn(logInUrl, browser)
	
	url = 'https://www.24th.com/checkout/cart/'
	content = readText(url, browser)
	browser.quit
	
	if content:
		pattern = re.compile(r'<h2 class=\"product-name\">.*?</a>', re.I|re.M|re.S)
		products = pattern.findall(content)
		
		for product in products:
			r = re.compile(r'<h2 class.*?<a href.*?>',re.I|re.M|re.S)
			s = r.sub ('',product)
			print s

	
if __name__ == '__main__':  
	main()
	raw_input('Press Enter to exit...')